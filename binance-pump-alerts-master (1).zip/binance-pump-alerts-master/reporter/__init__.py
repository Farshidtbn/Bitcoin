from .ReportGenerator import ReportGenerator
