from .TelegramSender import TelegramSender
